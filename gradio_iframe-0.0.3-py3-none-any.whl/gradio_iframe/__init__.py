
from .iframe import iFrame

__all__ = ['iFrame']
